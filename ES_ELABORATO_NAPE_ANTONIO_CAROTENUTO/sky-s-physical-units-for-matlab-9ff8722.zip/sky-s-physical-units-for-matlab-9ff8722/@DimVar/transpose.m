function v = transpose(v)

v.value = v.value.';

% 2014-05-16/Sartorius: simplified.