function v = floor(v)

v.value = floor(v.value);

% 2014-05-14/Sartorius: simplified.