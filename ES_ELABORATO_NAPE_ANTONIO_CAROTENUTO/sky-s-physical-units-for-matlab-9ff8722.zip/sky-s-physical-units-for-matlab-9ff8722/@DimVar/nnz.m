function out = nnz(v1)

out = nnz(v1.value);
