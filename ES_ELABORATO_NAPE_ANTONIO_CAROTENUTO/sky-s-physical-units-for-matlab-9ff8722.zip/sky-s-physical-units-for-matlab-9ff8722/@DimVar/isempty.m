function indexOut = isempty(v1)

indexOut = isempty(v1.value);
