function v = sum(v,varargin)

v.value = sum(v.value,varargin{:});

% 2014-05-16/Sartorius: Expanded to full functionality.