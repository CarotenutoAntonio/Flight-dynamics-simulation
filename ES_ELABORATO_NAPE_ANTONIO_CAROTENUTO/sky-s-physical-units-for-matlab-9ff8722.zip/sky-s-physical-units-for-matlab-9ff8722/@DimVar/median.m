function v = median(v,varargin)

v.value = median(v.value,varargin{:});

% 2014-05-15/Sartorius: Expanded to full functionality.