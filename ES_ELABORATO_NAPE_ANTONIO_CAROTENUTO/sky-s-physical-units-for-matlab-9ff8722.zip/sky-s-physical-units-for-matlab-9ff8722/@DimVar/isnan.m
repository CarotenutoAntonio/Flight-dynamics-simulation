function indexOut = isnan(v1)

indexOut = isnan(v1.value);
