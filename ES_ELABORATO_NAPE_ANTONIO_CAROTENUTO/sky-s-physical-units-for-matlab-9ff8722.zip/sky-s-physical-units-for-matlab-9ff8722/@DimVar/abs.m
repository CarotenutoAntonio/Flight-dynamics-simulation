function v = abs(v)

v.value = abs(v.value);

% 2014-05-14/Sartorius: simplified.