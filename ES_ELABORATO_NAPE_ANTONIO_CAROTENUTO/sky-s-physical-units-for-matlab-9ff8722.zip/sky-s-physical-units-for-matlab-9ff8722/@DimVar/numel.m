function out = numel(x)

out = numel(x.value);

% Created 2014-10-03.