function outSign = sign(v1)

outSign = sign(v1.value);
