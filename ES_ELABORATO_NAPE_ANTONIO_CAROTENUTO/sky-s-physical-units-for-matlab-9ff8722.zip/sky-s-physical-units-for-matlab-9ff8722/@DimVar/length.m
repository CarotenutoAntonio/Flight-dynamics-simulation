function nPoints = length(v1)

nPoints = length(v1.value);
