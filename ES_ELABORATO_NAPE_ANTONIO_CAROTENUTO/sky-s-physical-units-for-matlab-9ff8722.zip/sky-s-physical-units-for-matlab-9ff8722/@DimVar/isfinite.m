function indexOut = isfinite(v1)

indexOut = isfinite(v1.value);
