function indexOut = isnumeric(v1)

indexOut = isnumeric(v1.value);
