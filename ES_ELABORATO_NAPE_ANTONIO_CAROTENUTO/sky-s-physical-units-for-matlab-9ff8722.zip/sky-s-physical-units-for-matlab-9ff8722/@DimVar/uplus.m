function v = uplus(v)
% 

% 2014-05-16/Sartorius: simplified.