function outIndex = le(v1,v2)

if compatible(v1,v2)
    outIndex = v1.value <= v2.value;  
end

% 2014-05-14/Sartorius: simplified.