function disp(v)

disp(num2str(v,'%g '));

% Created 2014-09-19