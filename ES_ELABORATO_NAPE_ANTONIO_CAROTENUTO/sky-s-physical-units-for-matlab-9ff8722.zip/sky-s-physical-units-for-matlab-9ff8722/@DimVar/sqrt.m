function v = sqrt(v)

v.value = sqrt(v.value);
v.exponents = v.exponents/2;