function v = conj(v)

v.value = conj(v.value);

% 2014-05-14/Sartorius: simplified.