function v = trace(v)

v.value = trace(v.value);

% 2014-05-16/Sartorius: simplified.