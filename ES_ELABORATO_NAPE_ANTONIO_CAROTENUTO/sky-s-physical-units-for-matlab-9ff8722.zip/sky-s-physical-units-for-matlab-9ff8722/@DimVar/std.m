function v = std(v,varargin)

v.value = std(v.value,varargin{:});

% 2014-05-16/Sartorius: simplified; expanded to allow all std inputs.