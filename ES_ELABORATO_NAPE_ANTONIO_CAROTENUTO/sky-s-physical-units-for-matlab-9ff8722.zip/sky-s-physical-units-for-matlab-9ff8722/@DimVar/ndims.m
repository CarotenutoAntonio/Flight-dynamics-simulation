function n = ndims(v1)

n = ndims(v1.value);

% 2016-01-12 created.