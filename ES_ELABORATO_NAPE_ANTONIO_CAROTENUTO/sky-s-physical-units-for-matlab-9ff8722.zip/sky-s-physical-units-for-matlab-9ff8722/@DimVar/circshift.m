function v = circshift(v,shiftIndicator)

v.value = circshift(v.value,shiftIndicator);

% 2014-05-14/Sartorius: simplified.