function indexOut = isreal(v1)

indexOut = isreal(v1.value);
