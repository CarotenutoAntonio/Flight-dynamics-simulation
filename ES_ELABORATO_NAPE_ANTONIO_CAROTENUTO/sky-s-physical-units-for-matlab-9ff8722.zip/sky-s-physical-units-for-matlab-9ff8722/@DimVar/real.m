function v = real(v)

v.value = real(v.value);

% 2014-05-16/Sartorius: simplified.