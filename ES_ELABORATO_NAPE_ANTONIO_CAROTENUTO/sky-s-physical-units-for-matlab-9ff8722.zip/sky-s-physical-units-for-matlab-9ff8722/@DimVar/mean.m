function v = mean(v,varargin)

v.value = mean(v.value,varargin{:});

% 2014-05-15/Sartorius: Expanded to full functionality.