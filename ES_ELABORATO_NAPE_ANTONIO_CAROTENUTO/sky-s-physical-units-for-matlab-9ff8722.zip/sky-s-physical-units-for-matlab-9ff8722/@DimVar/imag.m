function v = imag(v)

v.value = imag(v.value);

% 2014-05-14/Sartorius: simplified.