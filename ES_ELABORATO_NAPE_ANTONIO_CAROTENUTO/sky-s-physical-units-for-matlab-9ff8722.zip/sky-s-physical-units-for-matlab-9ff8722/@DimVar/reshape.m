function v = reshape(v,varargin)

v.value = reshape(v.value,varargin{:});

% Created 2014-10-03