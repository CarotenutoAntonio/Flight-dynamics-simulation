function v = round(v)

v.value = round(v.value);

% 2014-05-16/Sartorius: simplified.