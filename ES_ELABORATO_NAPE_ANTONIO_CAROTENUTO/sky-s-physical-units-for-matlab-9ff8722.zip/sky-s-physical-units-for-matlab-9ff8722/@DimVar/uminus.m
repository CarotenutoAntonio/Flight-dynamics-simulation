function v = uminus(v)

v.value = -v.value;

% 2014-05-16/Sartorius: simplified.