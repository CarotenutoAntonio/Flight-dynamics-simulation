function v = ceil(v)

v.value = ceil(v.value);

% 2014-05-14/Sartorius: simplified.