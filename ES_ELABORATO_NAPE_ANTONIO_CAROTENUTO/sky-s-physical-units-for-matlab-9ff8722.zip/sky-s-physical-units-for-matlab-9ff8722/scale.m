function [out] = scale(varargin)
out = varargin{1};
end

% This function is called when scale is used on a non-DimVar.

% See DimVar.scale.